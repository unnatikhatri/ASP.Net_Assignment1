﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MessageBoard.Models
{
    public class MockComment : IComment
    {
        public OriginalPost GetCommentById(int commentId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Comment> GetComments()=>
         new List<Comment>
        {
            new Comment{CommentId=1, CommentContent="Nope!!!"},
            new Comment{CommentId=2, CommentContent="Yess!!"}

        };

        }
    }


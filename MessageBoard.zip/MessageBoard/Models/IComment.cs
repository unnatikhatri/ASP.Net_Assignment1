﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MessageBoard.Models
{
   public interface IComment
    {
        IEnumerable<Comment> GetComments();
        OriginalPost GetCommentById(int commentId);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MessageBoard.Models
{
    public class OriginalPost
    {
        public int PostId { get; set; }
        public string PostContent { get; set; }
        public int Like { get; set; }
        public Comment Comment { get; set; }
        public Share Share { get; set; }
    }
}

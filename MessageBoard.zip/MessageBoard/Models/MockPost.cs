﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MessageBoard.Models
{
    public class MockPost : IOriginalPost
    {
        public IEnumerable<OriginalPost> GetAllPosts() =>
         new List<OriginalPost>
        {
            new OriginalPost{PostId=1, PostContent="I hate Hoomans !! Do you ????"},
            new OriginalPost{PostId=2, PostContent="I love Dinosaurs !! Do you ????"}

        };

        public OriginalPost GetPostById(int postId)
        {
            throw new NotImplementedException();
        }
    }
}

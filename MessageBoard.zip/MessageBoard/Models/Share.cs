﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MessageBoard.Models
{
    public class Share
    {
        public int ShareId { get; set; }
        public List<OriginalPost> Shares { get; set; }
    }
}

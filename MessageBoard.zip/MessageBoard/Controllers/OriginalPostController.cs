﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MessageBoard.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MessageBoard.Controllers
{
    public class OriginalPostController : Controller
    {
        private readonly IOriginalPost _originalPostRepository;
        private readonly IComment _commentRepository;

        public OriginalPostController(IOriginalPost originalPost,IComment comment)
        {
            _originalPostRepository = originalPost;
            _commentRepository = comment;
        }

        public ViewResult List()
        {
            return View(_originalPostRepository.GetAllPosts());
        }
        
    }
}
